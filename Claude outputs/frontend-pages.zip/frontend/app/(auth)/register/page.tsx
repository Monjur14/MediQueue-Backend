'use client';

import { useState } from 'react';
import Link from 'next/link';
import { isValidPhoneNumber } from 'react-phone-number-input';
import { useRegister, getApiErrorMessage } from '@/hooks/api/auth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { PhoneInput } from '@/components/ui/phone-input';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';

interface FieldErrors {
  name?: string;
  email?: string;
  password?: string;
  phone?: string;
}

export default function RegisterPage() {
  const register = useRegister();

  const [form, setForm] = useState({
    full_name: '', email: '', password: '', phone: '',
  });
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({});

  const set = (field: keyof typeof form) =>
    (e: React.ChangeEvent<HTMLInputElement>) =>
      setForm((prev) => ({ ...prev, [field]: e.target.value }));

  const validate = (): boolean => {
    const next: FieldErrors = {};
    if (!form.full_name.trim()) next.name = 'Full name is required';
    if (!form.email)            next.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(form.email)) next.email = 'Enter a valid email';
    if (!form.password)         next.password = 'Password is required';
    else if (form.password.length < 8) next.password = 'At least 8 characters';
    if (form.phone && !isValidPhoneNumber(form.phone))
      next.phone = 'Invalid phone number for selected country';
    setFieldErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    register.mutate({
      full_name: form.full_name,
      email:     form.email,
      password:  form.password,
      phone:     form.phone || undefined,
    });
  };

  const apiError = register.error ? getApiErrorMessage(register.error) : null;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Create your account</CardTitle>
        <CardDescription>
          Free forever for patients — no payment required
        </CardDescription>
      </CardHeader>

      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4" noValidate>
          {apiError && (
            <div className="rounded-lg bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">
              {apiError}
            </div>
          )}

          <div className="space-y-1.5">
            <Label htmlFor="name">Full name</Label>
            <Input
              id="name"
              placeholder="John Doe"
              autoComplete="name"
              value={form.full_name}
              onChange={set('full_name')}
              error={fieldErrors.name}
              disabled={register.isPending}
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="you@example.com"
              autoComplete="email"
              value={form.email}
              onChange={set('email')}
              error={fieldErrors.email}
              disabled={register.isPending}
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="phone">
              Phone{' '}
              <span className="text-gray-400 font-normal text-xs">(optional)</span>
            </Label>
            <PhoneInput
              id="phone"
              value={form.phone}
              onChange={(v) => setForm((p) => ({ ...p, phone: v }))}
              error={fieldErrors.phone}
              disabled={register.isPending}
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              placeholder="Min. 8 characters"
              autoComplete="new-password"
              value={form.password}
              onChange={set('password')}
              error={fieldErrors.password}
              disabled={register.isPending}
            />
          </div>

          <Button type="submit" className="w-full" size="lg" disabled={register.isPending}>
            {register.isPending ? 'Creating account…' : 'Create free account'}
          </Button>
        </form>
      </CardContent>

      <CardFooter className="text-sm text-gray-500 justify-center">
        Already have an account?{' '}
        <Link href="/login" className="ml-1 text-blue-600 hover:underline font-medium">
          Sign in
        </Link>
      </CardFooter>
    </Card>
  );
}
