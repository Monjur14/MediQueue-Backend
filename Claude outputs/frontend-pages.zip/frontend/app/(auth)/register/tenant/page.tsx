'use client';

import { useState } from 'react';
import Link from 'next/link';
import { isValidPhoneNumber } from 'react-phone-number-input';
import { useRegisterTenant, getApiErrorMessage } from '@/hooks/api/auth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { PhoneInput } from '@/components/ui/phone-input';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { cn } from '@/lib/utils';

type PlanKey = 'solo' | 'clinic' | 'hospital';

const PLANS: Array<{
  key: PlanKey;
  name: string;
  price: string;
  limits: string;
  highlight?: boolean;
}> = [
  { key: 'solo',     name: 'Solo Doctor', price: '৳999/mo',   limits: '1 doctor · 50 patients/day' },
  { key: 'clinic',   name: 'Clinic',      price: '৳2,999/mo', limits: '10 doctors · 300 patients/day', highlight: true },
  { key: 'hospital', name: 'Hospital',    price: '৳9,999/mo', limits: 'Unlimited doctors & patients' },
];

interface FieldErrors {
  clinicName?: string;
  clinicPhone?: string;
  adminName?: string;
  email?: string;
  password?: string;
  phone?: string;
}

export default function RegisterTenantPage() {
  const registerTenant = useRegisterTenant();

  const [plan, setPlan] = useState<PlanKey>('clinic');
  const [form, setForm] = useState({
    clinic_name: '', clinic_phone: '', full_name: '', email: '', password: '', phone: '',
  });
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>({});

  const set = (field: keyof typeof form) =>
    (e: React.ChangeEvent<HTMLInputElement>) =>
      setForm((prev) => ({ ...prev, [field]: e.target.value }));

  const validate = (): boolean => {
    const next: FieldErrors = {};
    if (!form.clinic_name.trim()) next.clinicName  = 'Clinic name is required';
    if (!form.clinic_phone)       next.clinicPhone = 'Clinic phone is required';
    else if (!isValidPhoneNumber(form.clinic_phone))
      next.clinicPhone = 'Invalid phone number for selected country';
    if (!form.full_name.trim())   next.adminName   = 'Your name is required';
    if (!form.email)              next.email       = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(form.email)) next.email = 'Enter a valid email';
    if (!form.password)           next.password    = 'Password is required';
    else if (form.password.length < 8) next.password = 'At least 8 characters';
    if (form.phone && !isValidPhoneNumber(form.phone))
      next.phone = 'Invalid phone number for selected country';
    setFieldErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    registerTenant.mutate({
      clinic_name:  form.clinic_name,
      clinic_phone: form.clinic_phone,
      full_name:    form.full_name,
      email:        form.email,
      password:     form.password,
      phone:        form.phone || undefined,
      plan_name:    plan,
    });
  };

  const apiError = registerTenant.error
    ? getApiErrorMessage(registerTenant.error)
    : null;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Register your clinic</CardTitle>
        <CardDescription>Start managing your clinic with MediQueue</CardDescription>
      </CardHeader>

      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-5" noValidate>
          {apiError && (
            <div className="rounded-lg bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">
              {apiError}
            </div>
          )}

          {/* Plan selector */}
          <div className="space-y-2">
            <Label>Choose a plan</Label>
            <div className="grid grid-cols-3 gap-2">
              {PLANS.map((p) => (
                <button
                  key={p.key}
                  type="button"
                  onClick={() => setPlan(p.key)}
                  className={cn(
                    'relative rounded-lg border-2 p-3 text-left text-xs transition-colors',
                    plan === p.key
                      ? 'border-blue-600 bg-blue-50'
                      : 'border-gray-200 bg-white hover:border-gray-300',
                  )}
                >
                  {p.highlight && (
                    <span className="absolute -top-2 left-1/2 -translate-x-1/2 text-[10px] font-semibold bg-blue-600 text-white px-2 py-0.5 rounded-full">
                      Popular
                    </span>
                  )}
                  <div className="font-semibold text-gray-900 mt-1">{p.name}</div>
                  <div className="text-blue-600 font-medium mt-0.5">{p.price}</div>
                  <div className="text-gray-500 mt-0.5 leading-tight">{p.limits}</div>
                </button>
              ))}
            </div>
          </div>

          <div className="border-t border-gray-100" />

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5 col-span-2">
              <Label htmlFor="clinic_name">Clinic / Practice name</Label>
              <Input
                id="clinic_name"
                placeholder="City Medical Center"
                value={form.clinic_name}
                onChange={set('clinic_name')}
                error={fieldErrors.clinicName}
                disabled={registerTenant.isPending}
              />
            </div>

            <div className="space-y-1.5 col-span-2">
              <Label htmlFor="clinic_phone">Clinic phone</Label>
              <PhoneInput
                id="clinic_phone"
                value={form.clinic_phone}
                onChange={(v) => setForm((p) => ({ ...p, clinic_phone: v }))}
                error={fieldErrors.clinicPhone}
                disabled={registerTenant.isPending}
                placeholder="Clinic reception / front desk number"
              />
            </div>

            <div className="space-y-1.5 col-span-2">
              <Label htmlFor="full_name">Your name</Label>
              <Input
                id="full_name"
                placeholder="Dr. Rahman"
                value={form.full_name}
                onChange={set('full_name')}
                error={fieldErrors.adminName}
                disabled={registerTenant.isPending}
              />
            </div>

            <div className="space-y-1.5 col-span-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="clinic@example.com"
                value={form.email}
                onChange={set('email')}
                error={fieldErrors.email}
                disabled={registerTenant.isPending}
              />
            </div>

            <div className="space-y-1.5 col-span-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Min. 8 characters"
                value={form.password}
                onChange={set('password')}
                error={fieldErrors.password}
                disabled={registerTenant.isPending}
              />
            </div>

            <div className="space-y-1.5 col-span-2">
              <Label htmlFor="phone">
                Your personal phone{' '}
                <span className="text-gray-400 font-normal text-xs">(optional)</span>
              </Label>
              <PhoneInput
                id="phone"
                value={form.phone}
                onChange={(v) => setForm((p) => ({ ...p, phone: v }))}
                error={fieldErrors.phone}
                disabled={registerTenant.isPending}
                placeholder="Your personal mobile number"
              />
            </div>
          </div>

          <Button type="submit" className="w-full" size="lg" disabled={registerTenant.isPending}>
            {registerTenant.isPending ? 'Creating account…' : 'Create clinic account'}
          </Button>

          <p className="text-xs text-center text-gray-400">
            By registering you agree to our Terms of Service and Privacy Policy.
          </p>
        </form>
      </CardContent>

      <CardFooter className="text-sm text-gray-500 justify-center">
        Already have an account?{' '}
        <Link href="/login" className="ml-1 text-blue-600 hover:underline font-medium">
          Sign in
        </Link>
      </CardFooter>
    </Card>
  );
}
