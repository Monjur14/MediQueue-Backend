'use client';

import { useState } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { useLogin, getApiErrorMessage } from '@/hooks/api/auth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';

interface FormErrors {
  email?: string;
  password?: string;
}

export default function LoginPage() {
  const searchParams = useSearchParams();
  const registered   = searchParams.get('registered') === '1';
  const tenantJoined = searchParams.get('registered') === 'tenant';
  const setupDone    = searchParams.get('setup') === 'done';

  const login = useLogin();

  const [email, setEmail]     = useState('');
  const [password, setPassword] = useState('');
  const [fieldErrors, setFieldErrors] = useState<FormErrors>({});

  const validate = (): boolean => {
    const next: FormErrors = {};
    if (!email)    next.email    = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(email)) next.email = 'Enter a valid email';
    if (!password) next.password = 'Password is required';
    setFieldErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    login.mutate({ email, password });
  };

  const apiError = login.error ? getApiErrorMessage(login.error) : null;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Welcome back</CardTitle>
        <CardDescription>Sign in to your MediQueue account</CardDescription>
      </CardHeader>

      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4" noValidate>
          {/* Success banners */}
          {registered && (
            <div className="rounded-lg bg-green-50 border border-green-200 px-4 py-3 text-sm text-green-700">
              Account created! Sign in to continue.
            </div>
          )}
          {tenantJoined && (
            <div className="rounded-lg bg-blue-50 border border-blue-200 px-4 py-3 text-sm text-blue-700">
              Clinic registered! Complete payment to activate your account.
            </div>
          )}
          {setupDone && (
            <div className="rounded-lg bg-green-50 border border-green-200 px-4 py-3 text-sm text-green-700">
              Password set! You can now sign in.
            </div>
          )}

          {/* API error */}
          {apiError && (
            <div className="rounded-lg bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700">
              {apiError}
            </div>
          )}

          <div className="space-y-1.5">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="you@example.com"
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              error={fieldErrors.email}
              disabled={login.isPending}
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              placeholder="••••••••"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              error={fieldErrors.password}
              disabled={login.isPending}
            />
          </div>

          <Button type="submit" className="w-full" size="lg" disabled={login.isPending}>
            {login.isPending ? 'Signing in…' : 'Sign in'}
          </Button>
        </form>
      </CardContent>

      <CardFooter className="flex-col gap-3 text-sm text-gray-500">
        <p>
          New patient?{' '}
          <Link href="/register" className="text-blue-600 hover:underline font-medium">
            Create free account
          </Link>
        </p>
        <p>
          Clinic or doctor?{' '}
          <Link href="/register/tenant" className="text-blue-600 hover:underline font-medium">
            Register your clinic
          </Link>
        </p>
      </CardFooter>
    </Card>
  );
}
