'use client';

import { useState } from 'react';
import { useRequireAuth } from '@/hooks/useAuth';
import { useAuthStore } from '@/store/auth.store';
import { useQueueSocket } from '@/hooks/useQueueSocket';
import {
  useTodaySessions,
  useSessionTokens,
  useGiveToken,
  type QueueSession,
  type SessionToken,
} from '@/hooks/api/doctor';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

/* ------------------------------------------------------------------ */
/*  Status badge                                                        */
/* ------------------------------------------------------------------ */
function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; cls: string }> = {
    waiting:         { label: 'Waiting',    cls: 'bg-yellow-100 text-yellow-800' },
    called:          { label: 'Called',     cls: 'bg-green-100 text-green-800' },
    in_consultation: { label: 'In consult', cls: 'bg-blue-100 text-blue-800' },
    completed:       { label: 'Done',       cls: 'bg-gray-100 text-gray-800' },
    skipped:         { label: 'Skipped',    cls: 'bg-red-100 text-red-700' },
  };
  const { label, cls } = map[status] ?? { label: status, cls: 'bg-gray-100 text-gray-800' };
  return (
    <span className={cn('inline-block rounded-full px-2 py-0.5 text-xs font-semibold', cls)}>
      {label}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/*  Give token form                                                     */
/* ------------------------------------------------------------------ */
function GiveTokenForm({ sessionId }: { sessionId: string }) {
  const [phone, setPhone]   = useState('');
  const [message, setMessage] = useState('');
  const giveToken = useGiveToken();

  const handleSubmit = async () => {
    if (phone.trim().length < 6) return;
    try {
      const token = await giveToken.mutateAsync({ session_id: sessionId, patient_phone: phone.trim() });
      setMessage(`✓ Token #${token.token_number} assigned`);
      setPhone('');
      setTimeout(() => setMessage(''), 4000);
    } catch {
      setMessage('Failed — check phone number');
      setTimeout(() => setMessage(''), 4000);
    }
  };

  return (
    <div className="space-y-2">
      <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
        Assign token
      </p>
      <div className="flex gap-2">
        <input
          type="tel"
          placeholder="Patient phone number…"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
          className="flex-1 rounded-lg border border-gray-300 px-3 py-2 text-sm text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <Button
          type="button"
          onClick={handleSubmit}
          disabled={phone.trim().length < 6 || giveToken.isPending}
          className="shrink-0"
        >
          {giveToken.isPending ? '…' : 'Give Token'}
        </Button>
      </div>
      {message && (
        <p className={cn(
          'text-xs font-medium',
          message.startsWith('✓') ? 'text-green-700' : 'text-red-600',
        )}>
          {message}
        </p>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Session panel                                                       */
/* ------------------------------------------------------------------ */
function SessionPanel({
  session,
  accessToken,
}: {
  session: QueueSession;
  accessToken: string | null;
}) {
  const { data: tokens } = useSessionTokens(session.id);
  useQueueSocket(session.id, accessToken);

  const activeTokens = tokens?.filter((t) =>
    ['waiting', 'called', 'in_consultation'].includes(t.status)
  ) ?? [];

  const isOnBreak = session.status === 'break';

  return (
    <div className="rounded-xl border border-gray-200 bg-white overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 bg-gray-50 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <p className="font-semibold text-gray-900 text-sm">
              {session.department_name || 'General'}
            </p>
            <p className="text-xs text-gray-500">
              Dr. {session.doctor_name} · Now: #{session.current_token}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right">
              <p className="text-xl font-black text-blue-700">{session.waiting_count}</p>
              <p className="text-xs text-gray-500">waiting</p>
            </div>
            <span className={cn(
              'text-xs px-2 py-1 rounded-full font-semibold',
              isOnBreak           ? 'bg-orange-100 text-orange-700'
                : session.status === 'open' ? 'bg-green-100 text-green-700'
                : 'bg-gray-100 text-gray-700',
            )}>
              {isOnBreak ? '⏸ Break' : session.status === 'open' ? '● Open' : 'Closed'}
            </span>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* Give token */}
        {session.status !== 'closed' && (
          <GiveTokenForm sessionId={session.id} />
        )}

        {/* Queue list — read-only view for receptionist */}
        {activeTokens.length > 0 ? (
          <div className="space-y-2">
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
              In queue ({activeTokens.length})
            </p>
            {activeTokens.map((t: SessionToken) => (
              <div
                key={t.id}
                className={cn(
                  'flex items-center justify-between rounded-lg border px-3 py-2',
                  t.status === 'called' ? 'border-green-200 bg-green-50' : 'border-gray-100',
                )}
              >
                <div className="flex items-center gap-3">
                  <span className="text-base font-black text-gray-900">
                    #{t.token_number}
                  </span>
                  <div>
                    <p className="text-sm font-medium text-gray-900">{t.patient_name}</p>
                    <p className="text-xs text-gray-500">{t.patient_phone}</p>
                  </div>
                </div>
                <StatusBadge status={t.status} />
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-gray-400 text-center py-3">Queue is empty</p>
        )}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Page                                                                */
/* ------------------------------------------------------------------ */
export default function ReceptionistDeskPage() {
  const { user, loading } = useRequireAuth(['tenant_admin']);
  const accessToken = useAuthStore((s) => s.accessToken);
  const logout      = useAuthStore((s) => s.logout);

  const { data: sessions, isLoading } = useTodaySessions();
  const openSessions = sessions?.filter((s) => s.status !== 'closed') ?? [];

  if (loading || !user) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-3xl mx-auto px-4 pt-6 pb-12">

        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Receptionist Desk</h1>
            <p className="text-sm text-gray-500">{user.name}</p>
          </div>
          <Button variant="ghost" size="sm" onClick={logout}>
            Sign out
          </Button>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <svg className="animate-spin h-6 w-6 text-blue-500" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
            </svg>
          </div>
        ) : openSessions.length === 0 ? (
          <div className="rounded-xl border-2 border-dashed border-gray-200 p-10 text-center space-y-2">
            <p className="font-medium text-gray-900">No open sessions</p>
            <p className="text-sm text-gray-500">
              Doctor hasn&apos;t opened the queue yet today.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {openSessions.map((s) => (
              <SessionPanel key={s.id} session={s} accessToken={accessToken} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
