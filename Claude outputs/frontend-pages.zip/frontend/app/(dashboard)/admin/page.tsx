'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRequireAuth } from '@/hooks/useAuth';
import { useAuthStore } from '@/store/auth.store';
import { useTodaySessions, useOpenSession, useCloseSession } from '@/hooks/api/doctor';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '@/lib/api';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

/* ------------------------------------------------------------------ */
/*  Types                                                               */
/* ------------------------------------------------------------------ */
interface Doctor {
  id: string;
  full_name: string;
  email: string;
  phone: string;
  specialization: string | null;
  created_at: string;
}

interface Department {
  id: string;
  name: string;
  description: string | null;
  total_doctors: number;
}

/* ------------------------------------------------------------------ */
/*  Hooks                                                               */
/* ------------------------------------------------------------------ */
function useTenantDoctors() {
  return useQuery({
    queryKey: ['admin', 'doctors'],
    queryFn: () =>
      api.get<{ doctors: Doctor[] }>('/doctors').then((r) => r.data.doctors),
    staleTime: 30_000,
  });
}

function useTenantDepartments() {
  return useQuery({
    queryKey: ['admin', 'departments'],
    queryFn: () =>
      api.get<{ departments: Department[] }>('/departments').then((r) => r.data.departments),
    staleTime: 30_000,
  });
}

function useCreateDoctor() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: { full_name: string; email: string; phone: string }) =>
      api.post('/doctors', body),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['admin', 'doctors'] }),
  });
}

function useCreateDepartment() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: { name: string; description: string }) =>
      api.post('/departments', body),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['admin', 'departments'] }),
  });
}

/* ------------------------------------------------------------------ */
/*  Stat card                                                           */
/* ------------------------------------------------------------------ */
function StatCard({ label, value, sub }: { label: string; value: string | number; sub?: string }) {
  return (
    <div className="rounded-xl border border-gray-200 bg-white p-4">
      <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">{label}</p>
      <p className="text-3xl font-black text-gray-900 mt-1">{value}</p>
      {sub && <p className="text-xs text-gray-500 mt-0.5">{sub}</p>}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Open session card                                                   */
/* ------------------------------------------------------------------ */
function OpenSessionCard({ departments }: { departments: Department[] | undefined }) {
  const openSession  = useOpenSession();
  const [deptId, setDeptId]       = useState('');
  const [maxTokens, setMaxTokens] = useState(50);

  const hasDepts = departments && departments.length > 0;

  const handleOpen = async () => {
    await openSession.mutateAsync({
      department_id: deptId || undefined,
      max_tokens: maxTokens,
    });
    setDeptId('');
  };

  return (
    <div className="rounded-xl border-2 border-dashed border-blue-200 bg-blue-50 p-5 space-y-4">
      <div>
        <h2 className="font-semibold text-gray-900">Open today&apos;s queue</h2>
        <p className="text-xs text-gray-500 mt-0.5">Start accepting patients</p>
      </div>

      {/* Department picker — only when departments exist */}
      {hasDepts && (
        <div className="space-y-1">
          <label className="text-xs font-semibold text-gray-700 uppercase tracking-wide">
            Department
          </label>
          <select
            value={deptId}
            onChange={(e) => setDeptId(e.target.value)}
            className="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">All / none</option>
            {departments.map((d) => (
              <option key={d.id} value={d.id}>{d.name}</option>
            ))}
          </select>
        </div>
      )}

      <div className="space-y-1">
        <label className="text-xs font-semibold text-gray-700 uppercase tracking-wide">
          Max tokens: {maxTokens}
        </label>
        <input
          type="range"
          min={10}
          max={200}
          step={5}
          value={maxTokens}
          onChange={(e) => setMaxTokens(Number(e.target.value))}
          className="w-full accent-blue-600"
        />
        <div className="flex justify-between text-xs text-gray-400">
          <span>10</span><span>200</span>
        </div>
      </div>

      <Button
        onClick={handleOpen}
        disabled={openSession.isPending}
        className="w-full"
      >
        {openSession.isPending ? 'Opening…' : '▶  Open Queue'}
      </Button>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Active session summary card                                         */
/* ------------------------------------------------------------------ */
function ActiveSessionCard({
  session,
}: {
  session: { id: string; status: string; department_name: string; current_token: number; waiting_count: number; completed_count: number; active_break_id: string | null };
}) {
  const closeSession = useCloseSession();
  const isOnBreak = session.status === 'break';

  return (
    <div className={cn(
      'rounded-xl border bg-white p-4',
      isOnBreak ? 'border-orange-300' : 'border-green-300',
    )}>
      <div className="flex items-center justify-between mb-3">
        <div>
          <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
            {session.department_name || 'General'}
          </p>
          <p className="text-sm font-medium text-gray-900 mt-0.5">
            Session active · Serving #{session.current_token}
          </p>
        </div>
        <span className={cn(
          'text-xs px-2 py-1 rounded-full font-semibold',
          isOnBreak ? 'bg-orange-100 text-orange-700' : 'bg-green-100 text-green-700',
        )}>
          {isOnBreak ? '⏸ Break' : '● Open'}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4 text-center">
        <div className="rounded-lg bg-gray-50 py-2">
          <p className="text-xl font-bold text-gray-900">{session.waiting_count}</p>
          <p className="text-xs text-gray-500">waiting</p>
        </div>
        <div className="rounded-lg bg-gray-50 py-2">
          <p className="text-xl font-bold text-gray-900">{session.completed_count}</p>
          <p className="text-xs text-gray-500">done today</p>
        </div>
      </div>

      <div className="flex gap-2">
        <Link
          href="/doctor"
          className="flex-1 text-center rounded-lg bg-blue-600 text-white text-sm font-semibold py-2 hover:bg-blue-700 transition-colors"
        >
          Manage Queue →
        </Link>
        <button
          onClick={() => closeSession.mutate(session.id)}
          disabled={closeSession.isPending}
          className="text-xs font-medium text-gray-500 hover:text-gray-800 px-3 py-2 rounded-lg border border-gray-200 hover:bg-gray-50"
        >
          {closeSession.isPending ? '…' : 'Close'}
        </button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Add doctor modal                                                    */
/* ------------------------------------------------------------------ */
function AddDoctorForm({ onClose }: { onClose: () => void }) {
  const [form, setForm] = useState({ full_name: '', email: '', phone: '' });
  const [error, setError] = useState('');
  const create = useCreateDoctor();

  const handleSubmit = async () => {
    if (!form.full_name || !form.email || !form.phone) {
      setError('All fields are required');
      return;
    }
    try {
      await create.mutateAsync(form);
      onClose();
    } catch {
      setError('Failed to create doctor');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl w-full max-w-sm p-5 space-y-4">
        <h2 className="font-bold text-gray-900">Add Doctor</h2>
        {[
          { key: 'full_name', label: 'Full name', type: 'text' },
          { key: 'email',     label: 'Email',     type: 'email' },
          { key: 'phone',     label: 'Phone',     type: 'tel' },
        ].map(({ key, label, type }) => (
          <div key={key} className="space-y-1">
            <label className="text-xs font-semibold text-gray-700">{label}</label>
            <input
              type={type}
              value={form[key as keyof typeof form]}
              onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        ))}
        {error && <p className="text-xs text-red-600">{error}</p>}
        <div className="flex gap-2 pt-1">
          <Button variant="outline" onClick={onClose} className="flex-1">Cancel</Button>
          <Button onClick={handleSubmit} disabled={create.isPending} className="flex-1">
            {create.isPending ? 'Adding…' : 'Add Doctor'}
          </Button>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Add department modal                                                */
/* ------------------------------------------------------------------ */
function AddDepartmentForm({ onClose }: { onClose: () => void }) {
  const [form, setForm] = useState({ name: '', description: '' });
  const [error, setError] = useState('');
  const create = useCreateDepartment();

  const handleSubmit = async () => {
    if (!form.name) { setError('Name is required'); return; }
    try {
      await create.mutateAsync(form);
      onClose();
    } catch {
      setError('Failed to create department');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl w-full max-w-sm p-5 space-y-4">
        <h2 className="font-bold text-gray-900">Add Department</h2>
        <div className="space-y-1">
          <label className="text-xs font-semibold text-gray-700">Name</label>
          <input
            value={form.name}
            onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
            className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="e.g. Cardiology"
          />
        </div>
        <div className="space-y-1">
          <label className="text-xs font-semibold text-gray-700">Description (optional)</label>
          <input
            value={form.description}
            onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
            className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        {error && <p className="text-xs text-red-600">{error}</p>}
        <div className="flex gap-2 pt-1">
          <Button variant="outline" onClick={onClose} className="flex-1">Cancel</Button>
          <Button onClick={handleSubmit} disabled={create.isPending} className="flex-1">
            {create.isPending ? 'Adding…' : 'Add Department'}
          </Button>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Page                                                                */
/* ------------------------------------------------------------------ */
export default function AdminDashboardPage() {
  const { user, loading } = useRequireAuth(['tenant_admin']);
  const logout = useAuthStore((s) => s.logout);

  const [showAddDoctor, setShowAddDoctor] = useState(false);
  const [showAddDept, setShowAddDept]     = useState(false);

  const { data: sessions }    = useTodaySessions();
  const { data: doctors }     = useTenantDoctors();
  const { data: departments } = useTenantDepartments();

  const openSessions  = sessions?.filter((s) => s.status !== 'closed') ?? [];
  const totalWaiting  = openSessions.reduce((sum, s) => sum + s.waiting_count, 0);
  const totalDone     = sessions?.reduce((sum, s) => sum + s.completed_count, 0) ?? 0;
  // For solo doctor: the active session is the first (and only) open one
  const activeSession = openSessions[0];

  if (loading || !user) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 pt-6 pb-12">

        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-sm text-gray-500">{user.name}</p>
          </div>
          <Button variant="ghost" size="sm" onClick={logout}>
            Sign out
          </Button>
        </div>

        {/* Session card — open if no session, show active state if one exists */}
        <div className="mb-6">
          {activeSession ? (
            <ActiveSessionCard session={activeSession} />
          ) : (
            <OpenSessionCard departments={departments} />
          )}
        </div>

        {/* Quick nav — receptionist desk */}
        <Link
          href="/admin/queue"
          className="flex items-center justify-between rounded-xl bg-white border border-gray-200 px-4 py-3 mb-6 hover:bg-gray-50 transition-colors"
        >
          <div>
            <p className="font-semibold text-gray-900 text-sm">Receptionist Desk</p>
            <p className="text-xs text-gray-500 mt-0.5">Assign tokens to patients</p>
          </div>
          <span className="text-gray-400">→</span>
        </Link>

        {/* Today's stats */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <StatCard label="Open queues" value={openSessions.length} />
          <StatCard label="Waiting now" value={totalWaiting} />
          <StatCard label="Done today"  value={totalDone} />
        </div>

        {/* Doctors */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-bold text-gray-900">
              Doctors ({doctors?.length ?? 0})
            </h2>
            <button
              onClick={() => setShowAddDoctor(true)}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800"
            >
              + Add doctor
            </button>
          </div>
          <div className="rounded-xl border border-gray-200 overflow-hidden">
            {!doctors || doctors.length === 0 ? (
              <p className="text-sm text-gray-500 text-center py-6">No doctors yet</p>
            ) : (
              <div className="divide-y divide-gray-100">
                {doctors.map((d) => (
                  <div key={d.id} className="flex items-center justify-between px-4 py-3 bg-white">
                    <div>
                      <p className="font-medium text-gray-900 text-sm">{d.full_name}</p>
                      <p className="text-xs text-gray-500">{d.email} · {d.phone}</p>
                    </div>
                    {d.specialization && (
                      <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
                        {d.specialization}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Departments */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-bold text-gray-900">
              Departments ({departments?.length ?? 0})
            </h2>
            <button
              onClick={() => setShowAddDept(true)}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800"
            >
              + Add department
            </button>
          </div>
          <div className="rounded-xl border border-gray-200 overflow-hidden">
            {!departments || departments.length === 0 ? (
              <p className="text-sm text-gray-500 text-center py-6">No departments yet</p>
            ) : (
              <div className="divide-y divide-gray-100">
                {departments.map((d) => (
                  <div key={d.id} className="flex items-center justify-between px-4 py-3 bg-white">
                    <div>
                      <p className="font-medium text-gray-900 text-sm">{d.name}</p>
                      {d.description && (
                        <p className="text-xs text-gray-500">{d.description}</p>
                      )}
                    </div>
                    <span className="text-xs text-gray-500">
                      {d.total_doctors ?? 0} doctors
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {showAddDoctor && <AddDoctorForm onClose={() => setShowAddDoctor(false)} />}
      {showAddDept   && <AddDepartmentForm onClose={() => setShowAddDept(false)} />}
    </div>
  );
}
