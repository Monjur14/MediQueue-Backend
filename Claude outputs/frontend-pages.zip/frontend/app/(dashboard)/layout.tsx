'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useAuthStore } from '@/store/auth.store';
import { cn } from '@/lib/utils';

const navByRole: Record<string, { href: string; label: string }[]> = {
  patient: [
    { href: '/queue', label: 'My Queue' },
  ],
  doctor: [
    { href: '/doctor', label: 'My Queue' },
  ],
  tenant_admin: [
    { href: '/admin',       label: 'Dashboard' },
    { href: '/doctor',      label: 'My Queue' },
    { href: '/admin/queue', label: 'Receptionist' },
  ],
  super_admin: [
    { href: '/super', label: 'Platform' },
  ],
};

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const user     = useAuthStore((s) => s.user);

  const links = user ? (navByRole[user.role] ?? []) : [];

  return (
    <>
      {/* Only show nav when there are multiple links */}
      {links.length > 1 && (
        <nav className="bg-white border-b border-gray-200 sticky top-0 z-40">
          <div className="max-w-4xl mx-auto px-4 flex items-center gap-1 h-12">
            {links.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  'px-3 py-1.5 rounded-lg text-sm font-medium transition-colors',
                  pathname === link.href || pathname.startsWith(link.href + '/')
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-700 hover:bg-gray-100',
                )}
              >
                {link.label}
              </Link>
            ))}
          </div>
        </nav>
      )}
      {children}
    </>
  );
}
