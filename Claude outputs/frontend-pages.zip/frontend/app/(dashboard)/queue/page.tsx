'use client';

import { useRequireAuth } from '@/hooks/useAuth';
import { useAuthStore } from '@/store/auth.store';
import { useMyActiveToken } from '@/hooks/api/queue';
import { useQueueSocket } from '@/hooks/useQueueSocket';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

/* ------------------------------------------------------------------ */
/*  Status badge                                                        */
/* ------------------------------------------------------------------ */
function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; cls: string }> = {
    waiting:         { label: 'Waiting',        cls: 'bg-yellow-100 text-yellow-800' },
    called:          { label: 'Your turn!',      cls: 'bg-green-100 text-green-800 animate-pulse' },
    in_consultation: { label: 'In consultation', cls: 'bg-blue-100 text-blue-800' },
    completed:       { label: 'Done',            cls: 'bg-gray-100 text-gray-800' },
    skipped:         { label: 'Skipped',         cls: 'bg-red-100 text-red-700' },
  };
  const { label, cls } = map[status] ?? { label: status, cls: 'bg-gray-100 text-gray-800' };
  return (
    <span className={cn('inline-block rounded-full px-3 py-1 text-xs font-semibold', cls)}>
      {label}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/*  Active token card                                                   */
/* ------------------------------------------------------------------ */
function ActiveTokenCard() {
  const accessToken = useAuthStore((s) => s.accessToken);
  const { data: token, isLoading, isError, refetch } = useMyActiveToken();

  // WebSocket for real-time updates
  useQueueSocket(token?.session_id ?? null, accessToken);

  if (isLoading) {
    return (
      <div className="rounded-xl border border-gray-200 p-8 text-center">
        <svg className="animate-spin h-6 w-6 text-blue-500 mx-auto" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
        </svg>
        <p className="text-sm text-gray-700 mt-3">Checking for your token…</p>
      </div>
    );
  }

  if (isError || !token) {
    return (
      <div className="space-y-4">
        <div className="rounded-xl border-2 border-dashed border-gray-200 p-8 text-center">
          <div className="text-4xl mb-3">🏥</div>
          <p className="font-semibold text-gray-900">No active queue today</p>
          <p className="text-sm text-gray-700 mt-1">
            Visit the clinic reception — they'll assign you a token.
          </p>
        </div>
        <button
          onClick={() => refetch()}
          className="text-sm text-blue-600 hover:underline text-center w-full"
        >
          Refresh
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Clinic / doctor info */}
      <div className="rounded-xl border border-gray-200 bg-white p-4">
        <p className="text-xs font-semibold text-gray-700 uppercase tracking-wide">
          {token.department_name}
        </p>
        <p className="text-sm font-medium text-gray-900 mt-0.5">
          Dr. {token.doctor_name}
        </p>
        <p className="text-xs text-gray-700 mt-0.5">{token.clinic_name}</p>
        <div className="flex items-center gap-1 mt-2">
          <span className="text-xs text-gray-700">Now serving:</span>
          <span className="text-xs font-bold text-gray-900">#{token.current_token}</span>
        </div>
      </div>

      {/* My token */}
      <div className={cn(
        'rounded-xl border-2 p-5',
        token.status === 'called'
          ? 'border-green-400 bg-green-50'
          : 'border-blue-200 bg-blue-50',
      )}>
        {token.status === 'called' && (
          <p className="text-center text-green-700 font-bold text-sm mb-3 animate-bounce">
            🔔 Your turn — please go to the doctor!
          </p>
        )}

        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-gray-700 uppercase tracking-wide">
              Your token
            </p>
            <p className="text-5xl font-black text-blue-700 mt-1">#{token.my_token}</p>
          </div>
          <div className="text-right space-y-2">
            <StatusBadge status={token.status} />
            {token.status === 'waiting' && (
              <p className="text-2xl font-bold text-gray-900 mt-2">
                {token.patients_ahead === 0
                  ? "You're next!"
                  : `${token.patients_ahead} ahead`}
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Page                                                                */
/* ------------------------------------------------------------------ */
export default function PatientQueuePage() {
  const { user, loading } = useRequireAuth(['patient']);
  const logout = useAuthStore((s) => s.logout);

  if (loading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <svg className="animate-spin h-5 w-5 text-blue-500" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
        </svg>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-md mx-auto px-4 pt-6 pb-12">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-xl font-bold text-gray-900">MediQueue</h1>
            <p className="text-sm text-gray-700">Hello, {user.name}</p>
          </div>
          <Button variant="ghost" size="sm" onClick={logout}>
            Sign out
          </Button>
        </div>

        <ActiveTokenCard />
      </div>
    </div>
  );
}
