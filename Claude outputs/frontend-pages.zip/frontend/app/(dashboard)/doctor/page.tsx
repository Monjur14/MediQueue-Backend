'use client';

import Link from 'next/link';
import { useState } from 'react';
import { useRequireAuth } from '@/hooks/useAuth';
import { useAuthStore } from '@/store/auth.store';
import { useQueueSocket } from '@/hooks/useQueueSocket';
import {
  useTodaySessions,
  useSessionTokens,
  useCallNext,
  useSkipToken,
  useCompleteToken,
  useStartBreak,
  useEndBreak,
  useCloseSession,
  type QueueSession,
  type SessionToken,
} from '@/hooks/api/doctor';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

/* ------------------------------------------------------------------ */
/*  Status badge                                                        */
/* ------------------------------------------------------------------ */
function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; cls: string }> = {
    waiting:         { label: 'Waiting',    cls: 'bg-yellow-100 text-yellow-800' },
    called:          { label: 'Called',     cls: 'bg-green-100 text-green-800' },
    in_consultation: { label: 'In consult', cls: 'bg-blue-100 text-blue-800' },
    completed:       { label: 'Done',       cls: 'bg-gray-100 text-gray-800' },
    skipped:         { label: 'Skipped',    cls: 'bg-red-100 text-red-700' },
  };
  const { label, cls } = map[status] ?? { label: status, cls: 'bg-gray-100 text-gray-800' };
  return (
    <span className={cn('inline-block rounded-full px-2 py-0.5 text-xs font-semibold', cls)}>
      {label}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/*  Token row                                                           */
/* ------------------------------------------------------------------ */
function TokenRow({ token, sessionId }: { token: SessionToken; sessionId: string }) {
  const skip     = useSkipToken(sessionId);
  const complete = useCompleteToken(sessionId);
  const canAct   = token.status === 'called' || token.status === 'waiting';

  return (
    <div className={cn(
      'flex items-center justify-between px-4 py-3 rounded-lg border',
      token.status === 'called' ? 'border-green-300 bg-green-50' : 'border-gray-100 bg-white',
    )}>
      <div className="flex items-center gap-3">
        <span className={cn(
          'text-lg font-black',
          token.status === 'called' ? 'text-green-700' : 'text-gray-900',
        )}>
          #{token.token_number}
        </span>
        <div>
          <p className="text-sm font-medium text-gray-900">{token.patient_name}</p>
          <p className="text-xs text-gray-500">{token.patient_phone}</p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <StatusBadge status={token.status} />
        {canAct && (
          <>
            <button
              onClick={() => complete.mutate(token.id)}
              disabled={complete.isPending}
              className="text-xs font-medium text-green-700 hover:text-green-900 px-2 py-1 rounded hover:bg-green-100"
            >
              Done
            </button>
            <button
              onClick={() => skip.mutate(token.id)}
              disabled={skip.isPending}
              className="text-xs font-medium text-red-600 hover:text-red-800 px-2 py-1 rounded hover:bg-red-100"
            >
              Skip
            </button>
          </>
        )}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Session view — queue management only                               */
/* ------------------------------------------------------------------ */
function SessionView({
  session,
  accessToken,
}: {
  session: QueueSession;
  accessToken: string | null;
}) {
  const [breakMins, setBreakMins] = useState(10);
  const { data: tokens }  = useSessionTokens(session.id);
  const callNext          = useCallNext(session.id);
  const startBreak        = useStartBreak(session.id);
  const endBreak          = useEndBreak(session.id);
  const closeSession      = useCloseSession();

  useQueueSocket(session.id, accessToken);

  const activeTokens = tokens?.filter((t) =>
    ['waiting', 'called', 'in_consultation'].includes(t.status)
  ) ?? [];
  const doneTokens   = tokens?.filter((t) =>
    ['completed', 'skipped'].includes(t.status)
  ) ?? [];
  const isOnBreak = session.status === 'break';

  return (
    <div className="space-y-4">
      {/* Session overview card */}
      <div className="rounded-xl border border-gray-200 bg-white p-4">
        <div className="flex items-start justify-between mb-4">
          <div>
            {session.department_name && (
              <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-0.5">
                {session.department_name}
              </p>
            )}
            <p className="text-3xl font-black text-gray-900">
              #{session.current_token}
            </p>
            <p className="text-xs text-gray-500 mt-0.5">now serving</p>
          </div>
          <span className={cn(
            'text-xs px-2 py-1 rounded-full font-semibold',
            isOnBreak           ? 'bg-orange-100 text-orange-700'
              : session.status === 'open' ? 'bg-green-100 text-green-700'
              : 'bg-gray-100 text-gray-700',
          )}>
            {isOnBreak ? '⏸ Break' : session.status === 'open' ? '● Open' : 'Closed'}
          </span>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-3 gap-2 text-center mb-4">
          {[
            { label: 'Waiting',  value: session.waiting_count },
            { label: 'Done',     value: session.completed_count },
            { label: 'Skipped',  value: session.skipped_count },
          ].map(({ label, value }) => (
            <div key={label} className="rounded-lg bg-gray-50 py-2">
              <p className="text-lg font-bold text-gray-900">{value}</p>
              <p className="text-xs text-gray-500">{label}</p>
            </div>
          ))}
        </div>

        {/* Primary actions */}
        {isOnBreak ? (
          <Button
            onClick={() => session.active_break_id && endBreak.mutate(session.active_break_id)}
            disabled={endBreak.isPending || !session.active_break_id}
            className="w-full bg-orange-500 hover:bg-orange-600"
          >
            {endBreak.isPending ? 'Ending…' : 'End Break & Resume'}
          </Button>
        ) : (
          <div className="space-y-3">
            <Button
              onClick={() => callNext.mutate()}
              disabled={callNext.isPending || session.status !== 'open' || session.waiting_count === 0}
              className="w-full"
            >
              {callNext.isPending ? 'Calling…' : 'Call Next Patient →'}
            </Button>

            {/* Break control */}
            <div className="flex items-center gap-3 rounded-lg border border-gray-200 px-3 py-2">
              <div className="flex-1 min-w-0">
                <p className="text-xs text-gray-500 mb-1">Break: {breakMins} min</p>
                <input
                  type="range"
                  min={5}
                  max={60}
                  step={5}
                  value={breakMins}
                  onChange={(e) => setBreakMins(Number(e.target.value))}
                  className="w-full h-1.5 accent-orange-500"
                />
              </div>
              <button
                onClick={() => startBreak.mutate(breakMins)}
                disabled={startBreak.isPending || session.status !== 'open'}
                className="text-xs font-semibold text-orange-600 hover:text-orange-800 px-3 py-1.5 rounded border border-orange-200 hover:bg-orange-50 shrink-0 disabled:opacity-40"
              >
                {startBreak.isPending ? '…' : 'Take Break'}
              </button>
            </div>
          </div>
        )}

        {/* Close session */}
        <button
          onClick={() => closeSession.mutate(session.id)}
          disabled={closeSession.isPending}
          className="mt-3 text-xs text-gray-400 hover:text-gray-600 underline text-center w-full"
        >
          {closeSession.isPending ? 'Closing…' : 'Close session for today'}
        </button>
      </div>

      {/* Active queue list */}
      {activeTokens.length > 0 ? (
        <div className="space-y-2">
          <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
            In queue ({activeTokens.length})
          </p>
          {activeTokens.map((t: SessionToken) => (
            <TokenRow key={t.id} token={t} sessionId={session.id} />
          ))}
        </div>
      ) : (
        <div className="rounded-xl border-2 border-dashed border-gray-200 p-6 text-center">
          <p className="text-sm text-gray-500">Queue is empty</p>
        </div>
      )}

      {/* Completed / skipped collapsible */}
      {doneTokens.length > 0 && (
        <details className="rounded-xl border border-gray-100 overflow-hidden">
          <summary className="px-4 py-3 cursor-pointer text-xs font-semibold text-gray-500 uppercase tracking-wide bg-gray-50 hover:bg-gray-100 select-none">
            Done today ({doneTokens.length})
          </summary>
          <div className="divide-y divide-gray-100">
            {doneTokens.map((t: SessionToken) => (
              <div key={t.id} className="flex items-center justify-between px-4 py-2.5">
                <span className="text-sm font-medium text-gray-900">
                  #{t.token_number} — {t.patient_name}
                </span>
                <StatusBadge status={t.status} />
              </div>
            ))}
          </div>
        </details>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Page                                                                */
/* ------------------------------------------------------------------ */
export default function DoctorQueuePage() {
  const { user, loading } = useRequireAuth(['doctor', 'tenant_admin']);
  const accessToken       = useAuthStore((s) => s.accessToken);
  const logout            = useAuthStore((s) => s.logout);

  const { data: sessions, isLoading: sessionsLoading } = useTodaySessions();

  // Find this user's open/break session for today
  const mySession = user
    ? sessions?.find((s) => s.doctor_id === user.id && s.status !== 'closed')
      ?? (user.role === 'tenant_admin'
          ? sessions?.find((s) => s.status !== 'closed')
          : undefined)
    : undefined;

  if (loading || !user) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-2xl mx-auto px-4 pt-6 pb-12">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-xl font-bold text-gray-900">My Queue</h1>
            <p className="text-sm text-gray-500">Dr. {user.name}</p>
          </div>
          <Button variant="ghost" size="sm" onClick={logout}>
            Sign out
          </Button>
        </div>

        {sessionsLoading ? (
          <div className="flex justify-center py-12">
            <svg className="animate-spin h-6 w-6 text-blue-500" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
            </svg>
          </div>
        ) : mySession ? (
          <SessionView session={mySession} accessToken={accessToken} />
        ) : (
          /* No session yet — prompt to open one from admin dashboard */
          <div className="rounded-xl border-2 border-dashed border-gray-200 p-10 text-center space-y-4">
            <div className="text-4xl">🏥</div>
            <div>
              <p className="font-semibold text-gray-900">No active session</p>
              <p className="text-sm text-gray-500 mt-1">
                Open today&apos;s queue from the Dashboard first.
              </p>
            </div>
            <Link
              href="/admin"
              className="inline-block rounded-lg bg-blue-600 text-white text-sm font-semibold px-5 py-2 hover:bg-blue-700 transition-colors"
            >
              Go to Dashboard →
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
