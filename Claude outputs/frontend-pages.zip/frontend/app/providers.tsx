'use client';

import { useState, useEffect } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { AxiosError } from 'axios';
import { useAuthStore } from '@/store/auth.store';

function makeQueryClient() {
  return new QueryClient({
    defaultOptions: {
      queries: {
        // Data is fresh for 60s — no refetch within that window
        staleTime: 60_000,
        // Retry once on failure, but not on 4xx errors (those are app errors)
        retry: (failureCount, error) => {
          if (error instanceof AxiosError) {
            const status = error.response?.status ?? 0;
            if (status >= 400 && status < 500) return false;
          }
          return failureCount < 1;
        },
        // Refetch when user switches back to tab — good for live queue data
        refetchOnWindowFocus: true,
      },
      mutations: {
        // Never retry mutations — a failed POST should not be auto-retried
        retry: false,
      },
    },
  });
}

// Singleton for the browser — recreated only in tests / SSR
let browserQueryClient: QueryClient | undefined;

function getQueryClient() {
  if (typeof window === 'undefined') {
    // Server: always make a new client (no shared state between requests)
    return makeQueryClient();
  }
  if (!browserQueryClient) browserQueryClient = makeQueryClient();
  return browserQueryClient;
}

export function Providers({ children }: { children: React.ReactNode }) {
  const queryClient = getQueryClient();
  const hydrateFromStorage = useAuthStore((s) => s.hydrateFromStorage);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    hydrateFromStorage();
    setMounted(true);
  }, [hydrateFromStorage]);

  if (!mounted) return null;

  return (
    <QueryClientProvider client={queryClient}>
      {children}
    </QueryClientProvider>
  );
}
