'use client';

/**
 * WebSocket hook for real-time queue updates.
 * Joins a session room and invalidates TanStack Query cache on queue events.
 */
import { useEffect, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import { useQueryClient } from '@tanstack/react-query';

const WS_URL = process.env.NEXT_PUBLIC_API_URL?.replace('/api', '') ?? 'http://localhost:5001';

interface ETAPayload {
  session_id: string;
  avg_consultation_time: number;
  waiting_count: number;
  priority: boolean;
  eta_minutes: number;
  token_number: number;
}

export function useQueueSocket(
  sessionId: string | null,
  accessToken?: string | null,
) {
  const queryClient = useQueryClient();
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    if (!sessionId) return;

    const socket = io(WS_URL, {
      transports: ['websocket', 'polling'],
      autoConnect: true,
    });

    socketRef.current = socket;

    socket.on('connect', () => {
      socket.emit('join:session', {
        sessionId,
        token: accessToken ?? undefined,
      });
    });

    // Invalidate session queries AND patient's active token on every event
    const invalidate = () => {
      queryClient.invalidateQueries({
        queryKey: ['queue', 'session', sessionId],
      });
      queryClient.invalidateQueries({
        queryKey: ['queue', 'my-active-token'],
      });
      queryClient.invalidateQueries({
        queryKey: ['queue', 'sessions', 'today'],
      });
    };

    socket.on('queue:token_called',    invalidate);
    socket.on('queue:token_checkin',   invalidate);
    socket.on('queue:token_skipped',   invalidate);
    socket.on('queue:token_completed', invalidate);
    socket.on('queue:token_issued',    invalidate);
    socket.on('queue:session_closed',  invalidate);
    socket.on('queue:break_started',   invalidate);
    socket.on('queue:break_ended',     invalidate);

    // ETA update — optimistically patch the active token cache
    socket.on('queue:eta_update', (payload: ETAPayload) => {
      queryClient.setQueryData(
        ['queue', 'my-active-token'],
        (prev: { patients_ahead?: number } | undefined) => {
          if (!prev) return prev;
          return { ...prev, patients_ahead: payload.waiting_count };
        },
      );
      queryClient.setQueryData(
        ['queue', 'session', sessionId, 'my-token'],
        (prev: { patients_ahead?: number } | undefined) => {
          if (!prev) return prev;
          return { ...prev, patients_ahead: payload.waiting_count };
        },
      );
    });

    return () => {
      socket.disconnect();
      socketRef.current = null;
    };
  }, [sessionId, accessToken, queryClient]);
}
