/**
 * Clinics API hooks — all public endpoints, no auth required
 */
import { useQuery } from '@tanstack/react-query';
import { api } from '@/lib/api';

/* ------------------------------------------------------------------ */
/*  Types                                                               */
/* ------------------------------------------------------------------ */
export interface Clinic {
  id: string;
  name: string;
  slug: string;
  phone: string;
  logo_url: string | null;
  plan_name: string;
  total_departments: number;
  total_doctors: number;
}

export interface Department {
  id: string;
  name: string;
  description: string | null;
}

export interface DoctorPublic {
  id: string;
  full_name: string;
  phone: string;
}

export interface SessionStatus {
  id: string;
  status: 'open' | 'closed' | 'paused';
  max_tokens: number;
  current_token: number;
  total_issued: number;
  doctor_name: string;
  department_name: string;
  waiting_count: number;
  completed_count: number;
  skipped_count: number;
}

/* ------------------------------------------------------------------ */
/*  useSearchClinics                                                    */
/* ------------------------------------------------------------------ */
export function useSearchClinics(search: string) {
  return useQuery({
    queryKey: ['clinics', 'search', search],
    queryFn: () =>
      api.get<{ clinics: Clinic[] }>('/clinics', { params: { search } })
        .then((r) => r.data.clinics),
    enabled: search.trim().length >= 2,
    staleTime: 30_000,
  });
}

/* ------------------------------------------------------------------ */
/*  useClinicDepartments                                                */
/* ------------------------------------------------------------------ */
export function useClinicDepartments(slug: string | null) {
  return useQuery({
    queryKey: ['clinics', slug, 'departments'],
    queryFn: () =>
      api.get<{ clinic: Clinic; departments: Department[] }>(
        `/clinics/${slug}/departments`
      ).then((r) => r.data),
    enabled: !!slug,
    staleTime: 60_000,
  });
}

/* ------------------------------------------------------------------ */
/*  useSessionStatus  (public — no auth)                               */
/* ------------------------------------------------------------------ */
export function useSessionStatus(sessionId: string | null) {
  return useQuery({
    queryKey: ['queue', 'session', sessionId, 'status'],
    queryFn: () =>
      api.get<{ status: SessionStatus }>(
        `/queue/sessions/${sessionId}/status`
      ).then((r) => r.data.status),
    enabled: !!sessionId,
    refetchInterval: 15_000, // poll every 15s as fallback to WebSocket
    staleTime: 5_000,
  });
}
