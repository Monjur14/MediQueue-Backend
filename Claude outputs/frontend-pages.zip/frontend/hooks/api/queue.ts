/**
 * Queue API hooks — patient-facing
 */
import { useQuery } from '@tanstack/react-query';
import { api } from '@/lib/api';

/* ------------------------------------------------------------------ */
/*  Types                                                               */
/* ------------------------------------------------------------------ */
export interface MyToken {
  id: string;
  my_token: number;
  status: 'waiting' | 'called' | 'in_consultation' | 'completed' | 'skipped';
  fee_paid: boolean;
  fee_amount: number;
  patients_ahead: number;
  created_at: string;
}

export interface MyActiveToken {
  id: string;
  session_id: string;
  my_token: number;
  status: 'waiting' | 'called' | 'in_consultation' | 'completed' | 'skipped';
  fee_paid: boolean;
  fee_amount: number;
  patients_ahead: number;
  current_token: number;
  doctor_name: string;
  department_name: string;
  clinic_name: string;
  created_at: string;
}

/* ------------------------------------------------------------------ */
/*  useMyToken — patient's own token in a session (legacy)             */
/* ------------------------------------------------------------------ */
export function useMyToken(sessionId: string | null) {
  return useQuery({
    queryKey: ['queue', 'session', sessionId, 'my-token'],
    queryFn: () =>
      api.get<{ token: MyToken }>(
        `/queue/sessions/${sessionId}/my-token`
      ).then((r) => r.data.token),
    enabled: !!sessionId,
    refetchInterval: 15_000,
    staleTime: 5_000,
    retry: false,
  });
}

/* ------------------------------------------------------------------ */
/*  useMyActiveToken — auto-detects today's active token (no session ID) */
/* ------------------------------------------------------------------ */
export function useMyActiveToken() {
  return useQuery({
    queryKey: ['queue', 'my-active-token'],
    queryFn: () =>
      api.get<{ token: MyActiveToken }>('/queue/my-active-token')
        .then((r) => r.data.token),
    refetchInterval: 15_000,
    staleTime: 5_000,
    retry: false, // 404 = no token today — that's normal
  });
}
