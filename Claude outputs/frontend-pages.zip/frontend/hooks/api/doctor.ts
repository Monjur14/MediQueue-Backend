/**
 * Doctor & Admin queue management hooks
 */
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '@/lib/api';

/* ------------------------------------------------------------------ */
/*  Types                                                               */
/* ------------------------------------------------------------------ */
export interface QueueSession {
  id: string;
  status: 'open' | 'closed' | 'break';
  max_tokens: number;
  current_token: number;
  total_issued: number;
  doctor_name: string;
  doctor_id: string;
  department_name: string;
  department_id: string;
  waiting_count: number;
  completed_count: number;
  skipped_count: number;
  session_date: string;
  active_break_id: string | null;
}

export interface SessionToken {
  id: string;
  token_number: number;
  status: 'waiting' | 'called' | 'in_consultation' | 'completed' | 'skipped';
  patient_name: string;
  patient_phone: string;
  fee_paid: boolean;
  fee_amount: number;
  created_at: string;
}

export interface MyDepartment {
  id: string;
  name: string;
  description: string | null;
}

/* ------------------------------------------------------------------ */
/*  Admin / Doctor: today's sessions                                   */
/* ------------------------------------------------------------------ */
export function useTodaySessions() {
  return useQuery({
    queryKey: ['queue', 'sessions', 'today'],
    queryFn: () =>
      api.get<{ sessions: QueueSession[] }>('/queue/sessions/today')
        .then((r) => r.data.sessions),
    refetchInterval: 15_000,
    staleTime: 5_000,
    retry: 1, // don't hammer on 403/404
  });
}

/* ------------------------------------------------------------------ */
/*  Tokens in a session                                                 */
/* ------------------------------------------------------------------ */
export function useSessionTokens(sessionId: string | null) {
  return useQuery({
    queryKey: ['queue', 'session', sessionId, 'tokens'],
    queryFn: () =>
      api.get<{ tokens: SessionToken[] }>(`/queue/sessions/${sessionId}/tokens`)
        .then((r) => r.data.tokens),
    enabled: !!sessionId,
    refetchInterval: 10_000,
    staleTime: 3_000,
  });
}

/* ------------------------------------------------------------------ */
/*  Doctor's departments                                                */
/* ------------------------------------------------------------------ */
export function useMyDepartments() {
  return useQuery({
    queryKey: ['doctor', 'my-departments'],
    queryFn: () =>
      api.get<{ departments: MyDepartment[] }>('/doctors/my-departments')
        .then((r) => r.data.departments),
    staleTime: 60_000,
  });
}

/* ------------------------------------------------------------------ */
/*  Open session                                                        */
/* ------------------------------------------------------------------ */
export function useOpenSession() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: { department_id?: string; max_tokens: number }) =>
      api.post<{ session: QueueSession }>('/queue/sessions', body)
        .then((r) => r.data.session),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['queue', 'sessions', 'today'] });
    },
  });
}

/* ------------------------------------------------------------------ */
/*  Close session                                                       */
/* ------------------------------------------------------------------ */
export function useCloseSession() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (sessionId: string) =>
      api.put(`/queue/sessions/${sessionId}/close`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['queue', 'sessions', 'today'] });
    },
  });
}

/* ------------------------------------------------------------------ */
/*  Call next patient                                                   */
/* ------------------------------------------------------------------ */
export function useCallNext(sessionId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: () =>
      api.put(`/queue/sessions/${sessionId}/next`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['queue', 'session', sessionId] });
    },
  });
}

/* ------------------------------------------------------------------ */
/*  Skip token                                                          */
/* ------------------------------------------------------------------ */
export function useSkipToken(sessionId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (tokenId: string) =>
      api.put(`/queue/tokens/${tokenId}/skip`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['queue', 'session', sessionId] });
    },
  });
}

/* ------------------------------------------------------------------ */
/*  Complete token                                                      */
/* ------------------------------------------------------------------ */
export function useCompleteToken(sessionId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (tokenId: string) =>
      api.put(`/queue/tokens/${tokenId}/complete`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['queue', 'session', sessionId] });
    },
  });
}

/* ------------------------------------------------------------------ */
/*  Start break                                                         */
/* ------------------------------------------------------------------ */
export function useStartBreak(sessionId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (duration_minutes: number) =>
      api.post(`/queue/sessions/${sessionId}/break`, { duration_minutes }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['queue', 'sessions', 'today'] });
    },
  });
}

/* ------------------------------------------------------------------ */
/*  End break                                                           */
/* ------------------------------------------------------------------ */
export function useEndBreak(sessionId: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (breakId: string) =>
      api.put(`/queue/sessions/${sessionId}/break/${breakId}/end`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['queue', 'sessions', 'today'] });
    },
  });
}

/* ------------------------------------------------------------------ */
/*  Give token (receptionist assigns token to patient)                 */
/* ------------------------------------------------------------------ */
export function useGiveToken() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: { session_id: string; patient_phone: string }) =>
      api.post<{ token: SessionToken }>('/queue/tokens/give', {
        ...body,
        fee_amount: 0,
      }).then((r) => r.data.token),
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({
        queryKey: ['queue', 'session', variables.session_id],
      });
    },
  });
}
