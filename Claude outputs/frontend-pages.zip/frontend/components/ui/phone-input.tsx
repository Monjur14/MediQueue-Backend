'use client';

import { useEffect, useState } from 'react';
import ReactPhoneInput, {
  type Country,
  getCountries,
  getCountryCallingCode,
  isValidPhoneNumber,
} from 'react-phone-number-input';
import 'react-phone-number-input/style.css';
import { cn } from '@/lib/utils';

/* ------------------------------------------------------------------ */
/*  Auto-detect country from browser locale, fall back to BD           */
/* ------------------------------------------------------------------ */
function detectCountry(): Country {
  try {
    const locales =
      typeof navigator !== 'undefined'
        ? navigator.languages ?? [navigator.language]
        : [];
    for (const locale of locales) {
      const region = locale.split(/[-_]/)[1]?.toUpperCase();
      if (region && getCountries().includes(region as Country)) {
        return region as Country;
      }
    }
  } catch {
    /* ignore */
  }
  return 'BD';
}

/* ------------------------------------------------------------------ */
/*  Types                                                               */
/* ------------------------------------------------------------------ */
interface PhoneInputProps {
  value: string;
  onChange: (value: string) => void;
  error?: string;
  disabled?: boolean;
  id?: string;
  placeholder?: string;
}

/* ------------------------------------------------------------------ */
/*  Component                                                           */
/* ------------------------------------------------------------------ */
export function PhoneInput({
  value,
  onChange,
  error,
  disabled,
  id,
  placeholder,
}: PhoneInputProps) {
  const [country, setCountry] = useState<Country>('BD');
  const [touched, setTouched] = useState(false);
  const [internalError, setInternalError] = useState<string | undefined>();

  // Detect country on mount (client-side only)
  useEffect(() => {
    setCountry(detectCountry());
  }, []);

  const handleChange = (phone: string | undefined) => {
    onChange(phone ?? '');
    // Clear internal error while typing
    if (touched) setInternalError(undefined);
  };

  const handleBlur = () => {
    setTouched(true);
    if (!value) {
      setInternalError(undefined);
      return;
    }
    if (!isValidPhoneNumber(value)) {
      setInternalError('Invalid phone number for selected country');
    } else {
      setInternalError(undefined);
    }
  };

  const displayError = error ?? internalError;

  return (
    <div className="space-y-1">
      <div
        className={cn(
          'flex items-center rounded-md border bg-white transition-colors',
          displayError
            ? 'border-red-400 focus-within:ring-2 focus-within:ring-red-200'
            : 'border-gray-300 focus-within:ring-2 focus-within:ring-blue-200 focus-within:border-blue-400',
          disabled && 'opacity-50 pointer-events-none bg-gray-50',
        )}
      >
        <ReactPhoneInput
          id={id}
          international
          countryCallingCodeEditable={false}
          defaultCountry={country}
          country={country}
          onCountryChange={(c) => c && setCountry(c)}
          value={value}
          onChange={handleChange}
          onBlur={handleBlur}
          disabled={disabled}
          inputComponent={PhoneNumberInput}
          inputProps={{ placeholder: placeholder ?? 'Enter phone number' }}
          className="phone-input-wrapper w-full"
        />
      </div>

      {displayError && (
        <p className="text-xs text-red-600">{displayError}</p>
      )}

      {/* Hint showing expected format */}
      {!displayError && value && (
        <p className="text-xs text-gray-400">
          {isValidPhoneNumber(value) ? (
            <span className="text-green-600">✓ Valid number</span>
          ) : (
            <span>Enter your full number including area code</span>
          )}
        </p>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Custom input — forwards ref, strips non-digit chars on change      */
/* ------------------------------------------------------------------ */
import { forwardRef } from 'react';

const PhoneNumberInput = forwardRef<
  HTMLInputElement,
  React.InputHTMLAttributes<HTMLInputElement>
>(function PhoneNumberInput({ className, onChange, ...props }, ref) {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Allow digits, spaces, hyphens, parentheses — block letters and symbols
    const cleaned = e.target.value.replace(/[^0-9\s\-().+]/g, '');
    if (cleaned !== e.target.value) {
      e.target.value = cleaned;
    }
    onChange?.(e);
  };

  return (
    <input
      {...props}
      ref={ref}
      onChange={handleChange}
      inputMode="tel"
      className={cn(
        'flex-1 bg-transparent px-3 py-2 text-sm outline-none placeholder:text-gray-400',
        'disabled:cursor-not-allowed',
        className,
      )}
    />
  );
});
